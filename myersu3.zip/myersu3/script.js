function tableCreate() {
  var body = document.body;
  var tbl = document.createElement('table');
  tbl.style.width = '100%';
  tbl.setAttribute('border', '1');
  var tbdy = document.createElement('tbody');
  var thd = document.createElement('thead').insertRow();
  for (var i = 0; i < 3; i++) {
    var tr = document.createElement('tr');
    for (var j = 0; j < 4; j++) {
    	if (i == 0) {
      	var headi = document.createTextNode('header '+(j+1));
      	thd.insertCell().appendChild(headi);
      }
      var td = document.createElement('td');
      td.appendChild(document.createTextNode((i+1)+', '+(j+1)));
      tr.appendChild(td);
    }
    tbdy.appendChild(tr);
  }
  tbl.appendChild(thd);
  tbl.appendChild(tbdy);
  body.appendChild(tbl);
}
tableCreate();